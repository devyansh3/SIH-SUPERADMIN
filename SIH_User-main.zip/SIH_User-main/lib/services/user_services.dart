// import 'dart:js';

import 'package:user/model/user.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UserService{
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<Map<String,dynamic>> getslots() async {
    var userData = await _firestore
                .collection('slots')
                .get();
      print(userData.docs[0].data());
      return userData.docs[0].data();
  }
}