// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';

// import 'package:user/screens/login/verify_otp.dart';

// class FirebaseAuthMethods {
//   final FirebaseAuth _auth;
//   FirebaseAuthMethods(this._auth);

//   Future<void> phoneSignIn(
//     BuildContext context,
//     String phoneNumber,
//   ) async {
//     TextEditingController codeController = TextEditingController();
//     await _auth.verifyPhoneNumber(
//       phoneNumber: phoneNumber,
//       verificationCompleted: (PhoneAuthCredential credential) async {
//         await _auth.signInWithCredential(credential);
//       },
//       verificationFailed: (e) {
//         showSnackBar(context, e.message!);
//       },
//       codeSent: ((String verificationId, int? resendToken) async {
//         VerifyOtp(
//             onPressed: () async {
//               PhoneAuthCredential credential = PhoneAuthProvider.credential(
//                   verificationId: verificationId,
//                   smsCode: codeController.text.trim());
//             });
//       }),
//     );
//   }
// }
