

// // import 'dart:js';


// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:firebase_auth/firebase_auth.dart';

// class OperatorService{
  
//   final FirebaseFirestore _firestore = FirebaseFirestore.instance;
//   final FirebaseAuth _auth = FirebaseAuth.instance;

//   Future<Map<int,dynamic>> getSlots(String date) async{
//     // print(_auth.currentUser?.email);
//     // try{
//       Map<int,dynamic> mp = {
//         0:0,
//         1:0,
//         2:0,
//         3:0,
//         4:0,
//         5:0,
//         6:0,
//         7:0,
//       };
//       num total =0;
//       var q = await _firestore.collection('operators').get();
//       var data = q.docs;
//       for (var element in data) {
//         total += element.data()['slots_per_hour'];
//        }

//       // int total = 
      
// for(int i=0;i<8;i++){
//   num sum=0;
//    var q = await _firestore.collectionGroup('bookings').where('date', isEqualTo: date).where('slot', isEqualTo: i).get();
//    if(q.size == 0){
//     mp[i] = total;
//    }
//    else{
//     data = q.docs;
//     for (var element in data) {
//       sum += element.data()['remaining_slots'];
//     }
//    }
// }

//       var q = await _firestore.collection('slots').doc(date).get();
//       var data = q.data();
//       if(data != Null){
//        return mp; 
//       }
//       data.forEach((key, value) {
//           mp[key]-=value;
//        });
    
//       return mp;
//     // }catch(e){
//     //   print(e);
//     // }
//   }
// }