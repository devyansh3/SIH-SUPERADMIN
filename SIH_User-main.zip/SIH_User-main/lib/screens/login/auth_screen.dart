import 'package:flutter/material.dart';
import '../../global/widgets/reusable_button.dart';
import '../../global/widgets/reusable_text_field.dart';
import 'verify_otp.dart';

class AuthScreen extends StatefulWidget {
  static const id = '/auth_screen';
  const AuthScreen({Key? key}) : super(key: key);

  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  TextEditingController? contactController;

  @override
  void initState() {
    super.initState();
    contactController = TextEditingController();
  }

  @override
  void dispose() {
    super.dispose();
    contactController?.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      child: Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(50.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Image.asset('assets/aadhar.png'),
                ReusableTextField(
                  isContact: true,
                  controller: contactController!,
                ),
                ReusableButton(
                  text: 'Get OTP',
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (context) => VerifyOtp(
                        number: contactController!.text.trim(),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }
}
