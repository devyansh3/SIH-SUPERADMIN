import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:user/global/widgets/Forms/reusable_dropdowns.dart';
import 'package:user/screens/Selection/selection.dart';

class VerifyUser extends StatelessWidget {
  static const id = '/verify_user';
  const VerifyUser({Key? key}) : super(key: key);
  // static const Geolocator check = await _determinePosition();

  @override
  Widget build(BuildContext context) {
    TextEditingController nameController = TextEditingController();
    TextEditingController pinController = TextEditingController();
    TextEditingController houseController = TextEditingController();
    TextEditingController streetController = TextEditingController();
    TextEditingController landmarkController = TextEditingController();
    var map = <String, dynamic>{};

    return Scaffold(
      body: SingleChildScrollView(
        child: Align(
          alignment: Alignment.center,
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Image.asset(
                          "assets/uidai_english_logo.png",
                          width: 180,
                          height: 60,
                        ),
                        Image.asset("assets/aadhar.png", width: 70, height: 70),
                      ],
                    ),
                    const Divider(
                      thickness: 1,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        IconButton(
                          onPressed: () =>
                              Navigator.pushNamed(context, " SelectType.id"),
                          icon: const Icon(
                            Icons.chevron_left,
                            color: Colors.black,
                            size: 24.0,
                            semanticLabel: 'Back',
                          ),
                        )
                      ],
                    ),
                    const Divider(
                      thickness: 1,
                    )
                  ],
                ),
                const SizedBox(height: 20),
                const Text(
                  "Welcome User,",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Please enter the following details before proceeding.",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 40),
                const Text(
                  "Name: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Name',
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        "Pin Code: ",
                        style: TextStyle(
                          fontSize: 16.0,
                          color: Colors.black,
                        ),
                      ),
                      TextField(
                        controller: pinController,
                        keyboardType:
                            defaultTargetPlatform == TargetPlatform.iOS
                                ? const TextInputType.numberWithOptions(
                                    decimal: false, signed: false)
                                : TextInputType.number,
                        inputFormatters: [
                          FilteringTextInputFormatter.digitsOnly
                        ],
                        maxLength: 6,
                        decoration: const InputDecoration(
                          border: UnderlineInputBorder(),
                          labelText: 'Enter Pin Code',
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "Village/Town/City: ",
                        style: TextStyle(
                          fontSize: 16.0,
                          color: Colors.black,
                        ),
                      ),
                      ReusableDropDown(
                        onChanged: (newValue) {
                          map['city'] = newValue;
                        },
                        village: true,
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "District: ",
                        style: TextStyle(
                          fontSize: 16.0,
                          color: Colors.black,
                        ),
                      ),
                      ReusableDropDown(
                        onChanged: (newValue) {
                          map['district'] = newValue;
                        },
                        district: true,
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "State/Provice: ",
                        style: TextStyle(
                          fontSize: 16.0,
                          color: Colors.black,
                        ),
                      ),
                      ReusableDropDown(
                        onChanged: (newValue) {
                          map['state'] = newValue;
                        },
                        stateSelect: true,
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "Address Line 1: ",
                        style: TextStyle(
                          fontSize: 16.0,
                          color: Colors.black,
                        ),
                      ),
                      TextField(
                        controller: houseController,
                        decoration: const InputDecoration(
                          border: UnderlineInputBorder(),
                          labelText: 'Address Line 1: ',
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "Address Line 2: ",
                        style: TextStyle(
                          fontSize: 16.0,
                          color: Colors.black,
                        ),
                      ),
                      TextField(
                        controller: streetController,
                        decoration: const InputDecoration(
                          border: UnderlineInputBorder(),
                          labelText: 'Address Line 2',
                        ),
                      ),
                      const SizedBox(height: 20),
                      const Text(
                        "Landmark: ",
                        style: TextStyle(
                          fontSize: 16.0,
                          color: Colors.black,
                        ),
                      ),
                      TextField(
                        controller: landmarkController,
                        decoration: const InputDecoration(
                          border: UnderlineInputBorder(),
                          labelText: 'Landmark',
                        ),
                      ),
                      const SizedBox(height: 20)
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                    "Aadhaar Seva Kendra: ",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                ReusableDropDown(
                  sevaKendra: true,
                  onChanged: (newValue) {
                    map['sevaKendra'] = newValue;
                  },
                ),
                const SizedBox(height: 20),

                ElevatedButton(
                  onPressed: () => {
                          map['name'] = nameController.text,
                          map['pincode'] = pinController.text,
                          map['address'] = "${houseController.text} ${streetController.text} ${landmarkController.text}",
                          Navigator.pushNamed(context, SelectType.id),
                  },
                  // style: ,
                  child: const Text(
                    "Next",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
