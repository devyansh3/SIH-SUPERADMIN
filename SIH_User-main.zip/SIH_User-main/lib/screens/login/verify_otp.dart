import 'package:flutter/material.dart';
import 'package:user/screens/login/verify_user.dart';
import '../../global/widgets/reusable_button.dart';
import '../../global/widgets/reusable_text_field.dart';
import '../Selection/selection.dart';

class VerifyOtp extends StatefulWidget {
  static const id = '/otp_verify';
  final String number;
  const VerifyOtp({Key? key, required this.number}) : super(key: key);

  @override
  State<VerifyOtp> createState() => _VerifyOtpState();
}

class _VerifyOtpState extends State<VerifyOtp> {
  TextEditingController? otpController;
  @override
  void initState() {
    super.initState();
    otpController = TextEditingController();
  }

  @override
  void dispose() {
    super.dispose();
    otpController?.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Image.asset('assets/aadhar.png'),
              ReusableTextField(
                isContact: false,
                controller: otpController!,
              ),
              ReusableButton(
                  text: 'Verify',
                  onPressed: () => Navigator.pushNamed(context, VerifyUser.id)),
            ],
          ),
        ),
      ),
    );
  }
}
