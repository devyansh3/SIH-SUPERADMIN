import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';

class LocateOperator extends StatelessWidget {
  static const id = "/locate-operator";
  const LocateOperator({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Material(
      child: FlutterMap(
        options: MapOptions(
          center: LatLng(17.476092, 78.713597),
          zoom: 14.2,
        ),
        layers: [
          TileLayerOptions(
            urlTemplate: "https://tile.openstreetmap.org/{z}/{x}/{y}.png",
            subdomains: ['a', 'b', 'c'],
          ),
          MarkerLayerOptions(
            markers: [
              Marker(
                width: 45.0,
                height: 45.0,
                point: LatLng(17.476092, 78.713597),
                builder: (context) => Container(
                  child: IconButton(
                    icon: const Icon(Icons.location_on),
                    color: Colors.red,
                    iconSize: 45.0,
                    onPressed: () {print("hello");},
                  ),
                ),
              ),
              Marker(
                width: 45.0,
                height: 45.0,
                point: LatLng(17.49123, 78.723597),
                builder: (context) => Container(
                  child: IconButton(
                    icon: const Icon(Icons.motorcycle),
                    color: Colors.grey,
                    iconSize: 45.0,
                    onPressed: () {print("hello");},
                  ),
                ),
              ),
              Marker(
                width: 45.0,
                height: 45.0,
                point: LatLng(17.47123, 78.723597),
                builder: (context) => Container(
                  child: IconButton(
                    icon: const Icon(Icons.motorcycle),
                    color: Colors.grey,
                    iconSize: 45.0,
                    onPressed: () {print("hello");},
                  ),
                ),
              ),
              Marker(
                width: 45.0,
                height: 45.0,
                point: LatLng(17.47123, 78.703597),
                builder: (context) => Container(
                  child: IconButton(
                    icon: const Icon(Icons.motorcycle),
                    color: Colors.grey,
                    iconSize: 45.0,
                    onPressed: () {print("hello");},
                  ),
                ),
              ),
            ],
          )
        ],
        nonRotatedChildren: [
          AttributionWidget.defaultWidget(
            source: 'OpenStreetMap contributors',
            onSourceTapped: null,
          ),
        ],
      ),
    );
  }
}
