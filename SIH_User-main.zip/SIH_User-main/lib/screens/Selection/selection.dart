import 'package:flutter/material.dart';
import 'package:flutter_bounce/flutter_bounce.dart';
import 'package:user/screens/login/verify_user.dart';
import '../Selected/NewAadhaar/new_aadhaar.dart';
import '../Selected/UpdateAadhaar/update_aadhaar.dart';

class SelectType extends StatelessWidget {
  static const id = '/select_type';
  const SelectType({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Align(
          alignment: Alignment.center,
          child: Padding(
            padding: const EdgeInsets.all(20.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Image.asset(
                          "assets/uidai_english_logo.png",
                          width: 180,
                          height: 60,
                        ),
                        Image.asset("assets/aadhar.png", width: 70, height: 70),
                      ],
                    ),
                    const Divider(
                      thickness: 1,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        IconButton(
                          onPressed: () =>
                              Navigator.pushNamed(context, VerifyUser.id),
                          icon: const Icon(
                            Icons.chevron_left,
                            color: Colors.black,
                            size: 24.0,
                            semanticLabel: 'Back',
                          ),
                        )
                      ],
                    ),
                    const Divider(
                      thickness: 1,
                    )
                  ],
                ),
                const SizedBox(height: 20),
                const Text(
                  "Aadhaar Portal",
                  style: TextStyle(
                    fontSize: 20,
                    color: Colors.black,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 30),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: const [
                    Text(
                      "What is Aadhaar ?",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      "Aadhaar is a verifiable 12-digit identification number issued by UIDAI to the resident of India for free of cost",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      "What is Aadhaar Ecosystem ?",
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      "Aadhaar ecosystem comprises of core infrastructures with the objective of providing enrolment, update & authentication services.",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                Bounce(
                  onPressed: () => Navigator.pushNamed(context, NewEnrol.id),
                  duration: const Duration(milliseconds: 200),
                  child: Container(
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(15.0),
                        color: const Color.fromARGB(255, 244, 241, 241),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.8),
                            spreadRadius: 1,
                            blurRadius: 5,
                            offset: const Offset(0, 7),
                          )
                        ]),
                    margin: const EdgeInsets.only(top: 50.0),
                    padding: const EdgeInsets.fromLTRB(20, 20, 30, 20),
                    height: 200.0,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Image.asset(
                              "assets/point.png",
                            ),
                            const Padding(
                              padding: EdgeInsets.only(left: 10.0),
                              child: Text(
                                "New Aadhaar Enrolment",
                                style: TextStyle(
                                  fontSize: 18.0,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.black,
                                ),
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        const Text(
                          "Aadhaar is for every resident of India.",
                          style: TextStyle(fontSize: 16, color: Colors.green),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        const Text(
                          "For a new born to a senior citizen anyone can enrol for Aadhaar.",
                          style: TextStyle(fontSize: 16, color: Colors.black),
                        ),
                      ],
                    ),
                  ),
                ),
                // Divider(color: Colors.black),
                const SizedBox(height: 20.0),
                Bounce(
                  onPressed: () =>
                      Navigator.pushNamed(context, UpdateDetails.id),
                  duration: const Duration(milliseconds: 200),
                  child: Container(
                    padding: const EdgeInsets.all(20),
                    height: 200.0,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10.0),
                      color: const Color.fromARGB(255, 244, 241, 241),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.8),
                          spreadRadius: 0.5,
                          blurRadius: 5,
                          offset: const Offset(0, 7),
                        )
                      ],
                    ),
                    child: Column(
                      children: [
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Image.asset(
                              "assets/point.png",
                            ),
                            const Padding(
                              padding: EdgeInsets.only(left: 10.0),
                              child: Text(
                                "Update Aadhaar",
                                style: TextStyle(
                                  fontSize: 18.0,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.black,
                                ),
                              ),
                            )
                          ],
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        const Text(
                          "An array of services for aadhaar holders.",
                          style: TextStyle(fontSize: 16, color: Colors.green),
                        ),
                        const SizedBox(
                          height: 20,
                        ),
                        const Text(
                          "Aadhaar registered mobile numbers are essential for the following services.",
                          style: TextStyle(fontSize: 16, color: Colors.black),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
