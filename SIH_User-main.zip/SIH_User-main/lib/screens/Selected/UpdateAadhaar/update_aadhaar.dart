import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';
import '../../Selection/selection.dart';
import '../../../global/widgets/Forms/reusable_dropdowns.dart';
import 'update_form_2.dart';

enum ResidentType { resident, nri }

class UpdateDetails extends StatefulWidget {
  static const id = "/update_details";
  const UpdateDetails({Key? key}) : super(key: key);

  @override
  State<UpdateDetails> createState() => _UpdateDetailsState();
}

class UserData {
  ResidentType residency = ResidentType.resident;
  String appointmentType = "Update";
  String aadharNumber = "";
  String nameOnAadhaar = "";
  String verificationType = "";
  String selectedState = "";
  String selectedCity = "";
  String selectedAadhaarKendra = "";
  String name = "";
  String nameProof = "";
  String gender = "";
  String mobile = "";
  String email = "";
  String dob = "";
  bool biometric = false;
  String pincode = "";
  String village = "";
  String postOffice = "";
  String district = "";
  String state = "";
  String co = "";
  String house = "";
  String street = "";
  String landmark = "";
  String area = "";
  String addressProof = "";
  String selectedDate = "";
  String slotTimings = "";
}

class _UpdateDetailsState extends State<UpdateDetails> {
  ResidentType? _site = ResidentType.resident;
  TextEditingController aadhaarNumber = TextEditingController();
  TextEditingController aadhaarName = TextEditingController();
  String ccc = "";
  String verificationType = '', state = '', city = '', sevaKendra = '';
  var map = <String, String>{};

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 40),
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Image.asset("assets/uidai_english_logo.png",
                              width: 180, height: 60),
                          Image.asset("assets/aadhar.png",
                              width: 70, height: 70),
                        ],
                      ),
                      const Divider(
                        thickness: 1,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          IconButton(
                            onPressed: () =>
                                Navigator.pushNamed(context, SelectType.id),
                            icon: const Icon(
                              Icons.chevron_left,
                              color: Colors.black,
                              size: 24.0,
                              semanticLabel: 'Back',
                            ),
                          ),
                          const Text(
                            "Appointment Details",
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 16.0,
                            ),
                          ),
                        ],
                      ),
                      const Divider(
                        thickness: 1,
                      ),
                      const SizedBox(height: 30),
                    ],
                  ),
                ),
                const Text(
                  "Resident Type: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    fontWeight: FontWeight.w500,
                    color: Colors.black,
                  ),
                ),
                ListTile(
                  title: const Text('Indian Resident'),
                  leading: Radio(
                    value: ResidentType.resident,
                    groupValue: _site,
                    onChanged: (ResidentType? value) {
                      setState(() {
                        _site = value;
                      });
                    },
                  ),
                ),
                ListTile(
                  title: const Text('NRI'),
                  leading: Radio(
                    value: ResidentType.nri,
                    groupValue: _site,
                    onChanged: (ResidentType? value) {
                      setState(() {
                        _site = value;
                      });
                    },
                  ),
                ),
                Row(
                  children: const [
                    Text(
                      "Appointment type: ",
                      style: TextStyle(
                        color: Colors.black,
                        fontSize: 16,
                      ),
                    ),
                    Text(
                      "Update",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.bold),
                    )
                  ],
                ),

                // Input Aadhar Number
                const Padding(
                  padding: EdgeInsets.only(top: 20, bottom: 0),
                  child: Text(
                    "Enter your aadhaar number: ",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                ),
                TextField(
                  controller: aadhaarNumber,
                  keyboardType: defaultTargetPlatform == TargetPlatform.iOS
                      ? const TextInputType.numberWithOptions(
                          decimal: false, signed: false)
                      : TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  maxLength: 12,
                  decoration: const InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Aadhaar Number',
                  ),
                ),

                // Input Name on Aadhaar
                const Padding(
                  padding: EdgeInsets.only(top: 10, bottom: 0),
                  child: Text(
                    "Name on Aadhaar: ",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                ),
                TextField(
                  controller: aadhaarName,
                  decoration: const InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Name on Aadhaar',
                  ),
                ),

                // Verification Type
                const Padding(
                  padding: EdgeInsets.only(top: 20, bottom: 10),
                  child: Text(
                    "Application Verification type: ",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                ),
                ReusableDropDown(
                  onChanged: (newValue) {
                    verificationType = newValue;
                    map['verificationType'] = verificationType;
                  },
                  verificationType: true,
                ),

                // Address Details
                // State
                const Padding(
                  padding: EdgeInsets.only(top: 20, bottom: 10),
                  child: Text(
                    "State: ",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                ),
                ReusableDropDown(
                  stateSelect: true,
                  onChanged: (newValue) {
                    map['state'] = newValue;
                  },
                ),

                // City
                const Padding(
                  padding: EdgeInsets.only(top: 20, bottom: 10),
                  child: Text(
                    "City: ",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                ),

                // Aadhar seva Kendra
                ReusableDropDown(
                  city: true,
                  onChanged: (newValue) {
                    map['city'] = newValue;
                  },
                ),
                const Padding(
                  padding: EdgeInsets.only(top: 20, bottom: 10),
                  child: Text(
                    "Aadhaar Seva Kendra: ",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.black,
                    ),
                  ),
                ),
                ReusableDropDown(
                  sevaKendra: true,
                  onChanged: (newValue) {
                    map['sevaKendra'] = newValue;
                  },
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 20),
                  child: ElevatedButton(
                    onPressed: () => {
                      map['aadhaarNumber'] = aadhaarNumber.text,
                      map['aadhaarName'] = aadhaarName.text,
                      Navigator.of(context).push(
                        MaterialPageRoute(
                          builder: (context) => UpdatePersonalDetails(),
                        ),
                      )
                    },
                    // style: ,
                    child: const Text(
                      "Next",
                      style: TextStyle(
                        fontSize: 16,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
