import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'update_aadhaar.dart';
import '../../../global/widgets/Forms/reusable_dropdowns.dart';
import '../book_appointment.dart';

class UpdatePersonalDetails extends StatefulWidget {
  static const id = '/update_form_2';
  
  const UpdatePersonalDetails({Key? key}) : super(key: key);

  @override
  State<UpdatePersonalDetails> createState() => _UpdatePersonalDetailsState();
}

class _UpdatePersonalDetailsState extends State<UpdatePersonalDetails> {
  TextEditingController nameController = TextEditingController();
  TextEditingController mobileController = TextEditingController();
  TextEditingController dobController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController pinController = TextEditingController();
  TextEditingController coController = TextEditingController();
  TextEditingController houseController = TextEditingController();
  TextEditingController streetController = TextEditingController();
  TextEditingController landmarkController = TextEditingController();
  TextEditingController areaController = TextEditingController();

  bool name = false;
  bool dob = false;
  bool address = false;
  bool gender = false;
  bool mobile = false;
  bool biometric = false;
  bool email = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 40),
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Image.asset("assets/uidai_english_logo.png",
                              width: 180, height: 60),
                          Image.asset("assets/aadhar.png",
                              width: 70, height: 70),
                        ],
                      ),
                      const Divider(
                        thickness: 1,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          IconButton(
                            onPressed: () =>
                                Navigator.pushNamed(context, UpdateDetails.id),
                            icon: const Icon(
                              Icons.chevron_left,
                              color: Colors.black,
                              size: 24.0,
                              semanticLabel: 'Back',
                            ),
                          ),
                          const Text(
                            "Updation Details",
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 16.0,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const Divider(thickness: 1),
                const SizedBox(height: 30),
                const Text("Select fields to update: "),
                CheckboxListTile(
                  title: const Text("Name"),
                  value: name,
                  onChanged: (newValue) {
                    setState(() {
                      name = !name;
                    });
                  },
                  controlAffinity:
                      ListTileControlAffinity.leading, //  <-- leading Checkbox
                ),
                CheckboxListTile(
                  title: const Text("Gender"),
                  value: gender,
                  onChanged: (newValue) {
                    setState(() {
                      gender = !gender;
                    });
                  },
                  controlAffinity:
                      ListTileControlAffinity.leading, //  <-- leading Checkbox
                ),
                CheckboxListTile(
                  title: const Text("Mobile"),
                  value: mobile,
                  onChanged: (newValue) {
                    setState(() {
                      mobile = !mobile;
                    });
                  },
                  controlAffinity:
                      ListTileControlAffinity.leading, //  <-- leading Checkbox
                ),
                CheckboxListTile(
                  title: const Text("Email Id"),
                  value: email,
                  onChanged: (newValue) {
                    setState(() {
                      email = !email;
                    });
                  },
                  controlAffinity:
                      ListTileControlAffinity.leading, //  <-- leading Checkbox
                ),
                CheckboxListTile(
                  title: const Text("Address"),
                  value: address,
                  onChanged: (newValue) {
                    setState(() {
                      address = !address;
                    });
                  },
                  controlAffinity:
                      ListTileControlAffinity.leading, //  <-- leading Checkbox
                ),
                CheckboxListTile(
                  title: const Text("Date of birth"),
                  value: dob,
                  onChanged: (newValue) {
                    setState(() {
                      dob = !dob;
                    });
                  },
                  controlAffinity:
                      ListTileControlAffinity.leading, //  <-- leading Checkbox
                ),
                CheckboxListTile(
                  title: const Text("Biometric"),
                  value: biometric,
                  onChanged: (newValue) {
                    setState(() {
                      biometric = !biometric;
                    });
                  },
                  controlAffinity:
                      ListTileControlAffinity.leading, //  <-- leading Checkbox
                ),
                Padding(
                  padding: const EdgeInsets.only(top: 10, bottom: 20),
                  child: Row(
                    children: [
                      const Text(
                        "Applicable Fees: ",
                        style: TextStyle(
                          fontSize: 16.0,
                          color: Colors.green,
                        ),
                      ),
                      if (biometric)
                        const Text(
                          "100",
                          style: TextStyle(
                            fontSize: 16.0,
                            color: Colors.green,
                          ),
                        ),
                      if (!biometric &&
                          (name || gender || dob || email || mobile || address))
                        const Text(
                          "50",
                          style: TextStyle(
                            fontSize: 16.0,
                            color: Colors.green,
                          ),
                        ),
                      if (!biometric &&
                          !name &&
                          !gender &&
                          !dob &&
                          !email &&
                          !mobile &&
                          !address)
                        const Text(
                          "0",
                          style: TextStyle(
                            fontSize: 16.0,
                            color: Colors.green,
                          ),
                        ),
                    ],
                  ),
                ),

                // Check For Name Change
                if (name)
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                     const Text(
                        "New Name: ",
                        style: TextStyle(
                          fontSize: 16.0,
                          color: Colors.black,
                        ),
                      ),
                      TextField(
                        controller: nameController,
                        decoration: const InputDecoration(
                          border: UnderlineInputBorder(),
                          labelText: 'Name',
                        ),
                      ), 
                      Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Name Proof: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            ReusableDropDown(
                              onChanged: (newValue) {
                                print("verificationType");
                              },
                              nameProof: true,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                if (dob)
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "New Date of Birth: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            TextField(
                              controller: dobController,
                              decoration: const InputDecoration(
                                border: UnderlineInputBorder(),
                                labelText: 'Date of Birth',
                              ),
                            ),
                          ],
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Date of Birth Proof: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            ReusableDropDown(
                              onChanged: (newValue) {
                                print("verificationType");
                              },
                              birthProof: true,
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                if (gender)
                  Padding(
                    padding: const EdgeInsets.only(top: 20),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text(
                          "Select Gender: ",
                          style: TextStyle(
                            fontSize: 16.0,
                            color: Colors.black,
                          ),
                        ),
                        ReusableDropDown(
                          onChanged: (newValue) {
                            print("verificationType");
                          },
                          gender: true,
                        ),
                      ],
                    ),
                  ),
                if (email)
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "New Email ID: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            TextField(
                              controller: emailController,
                              decoration: const InputDecoration(
                                border: UnderlineInputBorder(),
                                labelText: 'Email ID',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                if (mobile)
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "New Mobile Number: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            TextField(
                              controller: mobileController,
                              keyboardType:
                                  defaultTargetPlatform == TargetPlatform.iOS
                                      ? const TextInputType.numberWithOptions(
                                          decimal: false, signed: false)
                                      : TextInputType.number,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly
                              ],
                              maxLength: 10,
                              decoration: const InputDecoration(
                                border: UnderlineInputBorder(),
                                labelText: 'New Mobile Number',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                if (address)
                  Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 20),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              "Pin Code: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            TextField(
                              controller: pinController,
                              keyboardType:
                                  defaultTargetPlatform == TargetPlatform.iOS
                                      ? const TextInputType.numberWithOptions(
                                          decimal: false, signed: false)
                                      : TextInputType.number,
                              inputFormatters: [
                                FilteringTextInputFormatter.digitsOnly
                              ],
                              maxLength: 6,
                              decoration: const InputDecoration(
                                border: UnderlineInputBorder(),
                                labelText: 'Enter Pin Code',
                              ),
                            ),
                            const SizedBox(height: 20),
                            const Text(
                              "Village/Town/City: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            ReusableDropDown(
                              onChanged: (newValue) {
                                print("verificationType");
                              },
                              village: true,
                            ),
                            const SizedBox(height: 20),
                            const Text(
                              "Post Office",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            ReusableDropDown(
                              onChanged: (newValue) {
                                print("verificationType");
                              },
                              postOffice: true,
                            ),
                            const SizedBox(height: 20),
                            const Text(
                              "District: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            ReusableDropDown(
                              onChanged: (newValue) {
                                print("verificationType");
                              },
                              district: true,
                            ),
                            const SizedBox(height: 20),
                            const Text(
                              "State/Provice: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            ReusableDropDown(
                              onChanged: (newValue) {
                                print("verificationType");
                              },
                              stateSelect: true,
                            ),
                            const SizedBox(height: 20),
                            const Text(
                              "C/O: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            TextField(
                              controller: coController,
                              decoration: const InputDecoration(
                                border: UnderlineInputBorder(),
                                labelText: 'C/O',
                              ),
                            ),
                            const SizedBox(height: 20),
                            const Text(
                              "House/Building No.: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            const TextField(
                              decoration: InputDecoration(
                                border: UnderlineInputBorder(),
                                labelText: 'House/Building No.',
                              ),
                            ),
                            const SizedBox(height: 20),
                            const Text(
                              "Street/Road/Lane: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            const TextField(
                              decoration: InputDecoration(
                                border: UnderlineInputBorder(),
                                labelText: 'Street/Road/Lane',
                              ),
                            ),
                            const SizedBox(height: 20),
                            const Text(
                              "Landmark: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            const TextField(
                              decoration: InputDecoration(
                                border: UnderlineInputBorder(),
                                labelText: 'Landmark',
                              ),
                            ),
                            const SizedBox(height: 20),
                            const Text(
                              "Area/Locality/Sector: ",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            const TextField(
                              decoration: InputDecoration(
                                border: UnderlineInputBorder(),
                                labelText: 'Area/Locality/Sector',
                              ),
                            ),
                            const SizedBox(height: 20),
                            const Text(
                              "Select Address Proof",
                              style: TextStyle(
                                fontSize: 16.0,
                                color: Colors.black,
                              ),
                            ),
                            ReusableDropDown(
                              onChanged: (newValue) {
                                print("verificationType");
                              },
                              addressProof: true,
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () =>
                      Navigator.pushNamed(context, BookAppointment.id),
                  // style: ,
                  child: const Text(
                    "Next",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
