import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import '../book_appointment.dart';
import '../../Selection/selection.dart';

import '../../../global/widgets/Forms/reusable_dropdowns.dart';

class NewPersonalDetails extends StatefulWidget {
  static const id = '/new_form_2';
  const NewPersonalDetails({Key? key}) : super(key: key);

  @override
  State<NewPersonalDetails> createState() => _NewPersonalDetailsState();
}

class _NewPersonalDetailsState extends State<NewPersonalDetails> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 40),
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Image.asset("assets/uidai_english_logo.png",
                              width: 180, height: 60),
                          Image.asset("assets/aadhar.png",
                              width: 70, height: 70),
                        ],
                      ),
                      const Divider(
                        thickness: 1,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          IconButton(
                            onPressed: () =>
                                Navigator.pushNamed(context, SelectType.id),
                            icon: const Icon(
                              Icons.chevron_left,
                              color: Colors.black,
                              size: 24.0,
                              semanticLabel: 'Back',
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const Divider(thickness: 1),
                const SizedBox(height: 30),
                const Text(
                  "Personal Details",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 30),
                const Text(
                  "Name: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                const TextField(
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Name',
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Name Proof: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                ReusableDropDown(
                  onChanged: (newValue) {
                    print("verificationType");
                  },
                  verificationType: true,
                ),
                const SizedBox(height: 20),
                const Text(
                  "Date of Birth: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                const TextField(
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Date of Birth',
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Date of Birth Proof: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                ReusableDropDown(
                  onChanged: (newValue) {
                    print("verificationType");
                  },
                  verificationType: true,
                ),
                const SizedBox(height: 20),
                const Text(
                  "Select Gender: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                ReusableDropDown(
                  onChanged: (newValue) {
                    print("verificationType");
                  },
                  verificationType: true,
                ),
                const SizedBox(height: 20),
                const Text(
                  "Email ID: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                const TextField(
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Email ID',
                  ),
                ),
                const SizedBox(height: 40),
                const Text(
                  "Address Details",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Pin Code: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                TextField(
                  keyboardType: defaultTargetPlatform == TargetPlatform.iOS
                      ? const TextInputType.numberWithOptions(
                          decimal: false, signed: false)
                      : TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  maxLength: 6,
                  decoration: const InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Enter Pin Code',
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Village/Town/City: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                ReusableDropDown(
                  onChanged: (newValue) {
                    print("verificationType");
                  },
                  verificationType: true,
                ),
                const SizedBox(height: 20),
                const Text(
                  "Post Office",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                ReusableDropDown(
                  onChanged: (newValue) {
                    print("verificationType");
                  },
                  verificationType: true,
                ),
                const SizedBox(height: 20),
                const Text(
                  "District: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                ReusableDropDown(
                  onChanged: (newValue) {
                    print("verificationType");
                  },
                  verificationType: true,
                ),
                const SizedBox(height: 20),
                const Text(
                  "State/Provice: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                ReusableDropDown(
                  onChanged: (newValue) {
                    print("verificationType");
                  },
                  verificationType: true,
                ),
                const SizedBox(height: 20),
                const Text(
                  "C/O: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                const TextField(
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'C/O',
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "House/Building No.: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                const TextField(
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'House/Building No.',
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Street/Road/Lane: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                const TextField(
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Street/Road/Lane',
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Landmark: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                const TextField(
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Landmark',
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Area/Locality/Sector: ",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                const TextField(
                  decoration: InputDecoration(
                    border: UnderlineInputBorder(),
                    labelText: 'Area/Locality/Sector',
                  ),
                ),
                const SizedBox(height: 20),
                const Text(
                  "Select Address Proof",
                  style: TextStyle(
                    fontSize: 16.0,
                    color: Colors.black,
                  ),
                ),
                ReusableDropDown(
                  onChanged: (newValue) {
                    print("verificationType");
                  },
                  verificationType: true,
                ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: () =>
                      Navigator.pushNamed(context, BookAppointment.id),
                  // style: ,
                  child: const Text(
                    "Next",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
