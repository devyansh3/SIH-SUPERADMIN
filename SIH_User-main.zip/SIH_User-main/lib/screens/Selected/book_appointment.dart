import 'dart:html';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:user/screens/booked.dart';
import '../Selection/selection.dart';
import 'package:flutter/cupertino.dart';

class BookAppointment extends StatefulWidget {
  static const id = '/book_appointment';
  const BookAppointment({Key? key}) : super(key: key);

  @override
  State<BookAppointment> createState() => _BookAppointmentState();
}

class _BookAppointmentState extends State<BookAppointment> {
  TextEditingController dateInput = TextEditingController();
  DateTime now = DateTime.now();
  DateTime date = DateTime(2022, 08, 25);
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  var black = Colors.green;
  // List<bool> pressAttention = [false,false,false,false,false,false,false,false,false,false];
  
  bool pressAttention3 = false;
  bool pressAttention1 = false;
  bool pressAttention4 = false;
  bool pressAttention2 = false;
  bool pressAttention5 = false;
  bool pressAttention6 = false;
  bool pressAttention7 = false;
  bool pressAttention8 = false;
  bool pressAttention9 = false;
  bool pressAttention10 = false;

  
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: SingleChildScrollView(
          child: Container(
            padding: const EdgeInsets.fromLTRB(20, 10, 20, 40),
            child: Column(
              // mainAxisAlignment: MainAxisAlignment.center,AQ
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Image.asset("assets/uidai_english_logo.png",
                              width: 180, height: 60),
                          Image.asset("assets/aadhar.png",
                              width: 70, height: 70),
                        ],
                      ),
                      const Divider(
                        thickness: 1,
                      ),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          IconButton(
                            onPressed: () =>
                                Navigator.pushNamed(context, SelectType.id),
                            icon: const Icon(
                              Icons.chevron_left,
                              color: Colors.black,
                              size: 24.0,
                              semanticLabel: 'Back',
                            ),
                          ),
                          const Text(
                            "Book Appointment",
                            style: TextStyle(
                              color: Colors.black,
                              fontSize: 16.0,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                const Divider(thickness: 1),
                const SizedBox(height: 30),
                const Text(
                  "Select a date: ",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),
                SizedBox(
                  height: 100,
                  child: CupertinoDatePicker(
                    mode: CupertinoDatePickerMode.date,
                    initialDateTime: DateTime(now.year, now.month, now.day + 1),
                    onDateTimeChanged: (DateTime newDate) {
                      setState(() => date = newDate);
                    },
                  ),
                ),
                const SizedBox(height: 40),
                const Text(
                  "Pick a slot: ",
                  style: TextStyle(
                    color: Colors.black,
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 20),
                // ButtonTheme(
                //   alignedDropdown: true,
                //   child: DropdownButtonFormField(
                //       // value: offerPercentageController.text.isEmpty
                //       //    ? null
                //       //    : offerPercentageController.text,
                //       icon: const Padding(
                //         padding: EdgeInsets.only(right: 4.0),
                //         child: Icon(Icons.keyboard_arrow_down_outlined),
                //       ),
                //       items: [
                //         '20',
                //         '25',
                //         '30',
                //         '35',
                //         '40',
                //         '45',
                //         '50',
                //       ]
                //           .map((e) =>
                //               DropdownMenuItem(child: Text("$e AM"), value: e))
                //           .toList(),
                //       onChanged: (value) {}),
                // ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    FlatButton(
                      onPressed: () =>
                          setState(() => pressAttention1 = !pressAttention1),
                      color: pressAttention1 ? Colors.blueAccent : Colors.green,
                      child: const Text(
                        "09:00AM",
                        style: TextStyle(color: Colors.white),
                      ),
                    ),
                    
                    FlatButton(
                        onPressed: () =>
                            setState(() => pressAttention2 = !pressAttention2),
                        color:
                            pressAttention2 ? Colors.blueAccent : Colors.green,
                        child: const Text(
                          "10:00AM",
                          style: TextStyle(color: Colors.white),
                        )),
                    FlatButton(
                        onPressed: () =>
                            setState(() => pressAttention3 = !pressAttention3),
                        color:
                            pressAttention3 ? Colors.blueAccent : Colors.green,
                        // color: Colors.grey,
                        child: const Text(
                          "11:00AM",
                          style: TextStyle(color: Colors.white),
                        )),
                  ],
                ),
                const SizedBox(height: 20,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    FlatButton(
                        onPressed: () =>
                            setState(() => pressAttention4 = !pressAttention4),
                        color:
                            pressAttention4 ? Colors.blueAccent : Colors.green,
                        child: const Text(
                          "12:00PM",
                          style: TextStyle(color: Colors.white),
                        )),
                    FlatButton(
                        onPressed: () =>
                            setState(() => pressAttention5 = !pressAttention5),
                        color:
                            pressAttention5 ? Colors.blueAccent : Colors.green,
                        child: const Text(
                          "01:00PM",
                          style: TextStyle(color: Colors.white),
                        )),
                    FlatButton(
                        onPressed: () =>
                            setState(() => pressAttention6 = !pressAttention6),
                        color:
                            pressAttention6 ? Colors.blueAccent : Colors.green,
                        child: const Text(
                          "02:00PM",
                          style: TextStyle(color: Colors.white),
                        )),
                  ],
                ),
                const SizedBox(height: 20,),

                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    FlatButton(
                        onPressed: () =>
                            setState(() => pressAttention7 = !pressAttention7),
                        color:
                            pressAttention7 ? Colors.blueAccent : Colors.green,
                        child: const Text(
                          "03:00PM",
                          style: TextStyle(color: Colors.white),
                        )),
                    FlatButton(
                        onPressed: () =>
                            setState(() => pressAttention8 = !pressAttention8),
                        color:
                            pressAttention8 ? Colors.blueAccent : Colors.green,
                        child: const Text(
                          "04:00PM",
                          style: TextStyle(color: Colors.white),
                        )),
                    FlatButton(
                        onPressed: () =>
                            setState(() => pressAttention9 = !pressAttention9),
                        color:
                            pressAttention9 ? Colors.blueAccent : Colors.green,
                        child: const Text(
                          "05:00PM",
                          style: TextStyle(color: Colors.white),
                        )),
                  ],
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    FlatButton(
                        onPressed: () => setState(
                            () => pressAttention10 = !pressAttention10),
                        color:
                            pressAttention10 ? Colors.blueAccent : Colors.green,
                        child: const Text(
                          "06:00PM",
                          style: TextStyle(color: Colors.white),
                        )),
                  ],
                ),
                // InkWell(
                //   onTap: () {
                //     setState(
                //       () {
                //         black = (black == Colors.green)
                //             ? Colors.blue
                //             : Colors.green;
                //       },
                //     );
                //   },
                //   child: Center(
                //     child: Container(
                //       height: 40,
                //       width: 100,
                //       decoration: BoxDecoration(
                //         border: Border.all(color: black, width: 2),
                //       ),
                //       child: Center(
                //         child: const Text(
                //           "",
                //           style: const TextStyle(
                //             color: Colors.black,
                //             fontSize: 17,
                //             fontWeight: FontWeight.bold,
                //           ),
                //         ),
                //       ),
                //     ),
                //   ),
                // ),
                const SizedBox(height: 40),
                ElevatedButton(
                  onPressed: () => Navigator.pushNamed(context, BookedSlot.id),
                  // style: ,
                  child: const Text(
                    "Next",
                    style: TextStyle(
                      fontSize: 16,
                      color: Colors.white,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
