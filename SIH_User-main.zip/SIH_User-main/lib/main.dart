import 'package:flutter/material.dart';
import 'package:user/screens/booked.dart';
import 'package:user/screens/feedback.dart';
import 'package:user/screens/locate_operator.dart';
import 'package:user/screens/login/verify_user.dart';
import 'package:user/screens/show_map.dart';
import 'screens/Selected/NewAadhaar/new_form_2.dart';
import 'screens/Selected/UpdateAadhaar/update_form_2.dart';
import 'screens/Selected/book_appointment.dart';
import 'screens/login/auth_screen.dart';
import 'screens/login/verify_otp.dart';
import 'screens/Selection/selection.dart';
import 'screens/Selected/NewAadhaar/new_aadhaar.dart';
import 'screens/Selected/UpdateAadhaar/update_aadhaar.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    // final wordPair = WordPair.random();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      routes: {
        AuthScreen.id: (context) => const AuthScreen(),
        VerifyOtp.id: (context) => const VerifyOtp(
              number: "",
            ),
        VerifyUser.id : (context) => const VerifyUser(),
        SelectType.id: (context) => const SelectType(),
        NewEnrol.id: (context) => const NewEnrol(),
        UpdateDetails.id: (context) => const UpdateDetails(),
        UpdatePersonalDetails.id: (context) => const UpdatePersonalDetails(),
        NewPersonalDetails.id: (context) => const NewPersonalDetails(),
        BookAppointment.id: (context) => const BookAppointment(),
        ShowMap.id: (context) => const ShowMap(),
        LocateOperator.id : (context) => const LocateOperator(),
        BookedSlot.id : (context) => const BookedSlot(),
        FeedBack.id: (context) => const FeedBack(),
      },
      initialRoute: AuthScreen.id,
    );
  }
}
