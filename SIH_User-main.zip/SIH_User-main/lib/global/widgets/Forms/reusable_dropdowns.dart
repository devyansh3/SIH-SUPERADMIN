import 'package:flutter/material.dart';

// ignore: must_be_immutable
class ReusableDropDown extends StatefulWidget {
  String selected;
  bool verificationType;
  bool stateSelect;
  bool city;
  bool sevaKendra;
  bool nameProof;
  bool birthProof;
  bool gender;
  bool village;
  bool postOffice;
  bool addressProof;
  bool district;

  Function? onChanged;

  ReusableDropDown({
    Key? key,
    this.verificationType = false,
    this.stateSelect = false,
    this.city = false,
    this.sevaKendra = false,
    this.nameProof = false,
    this.birthProof = false,
    this.gender = false,
    this.village = false,
    this.postOffice = false,
    this.addressProof = false,
    this.district = false,
    this.selected = "",
    this.onChanged,
  }) : super(key: key);

  @override
  State<ReusableDropDown> createState() => _ReusableDropDownState();
}

class _ReusableDropDownState extends State<ReusableDropDown> {
  String dropdownValue = 'Select';

  @override
  Widget build(BuildContext context) {
    List<String> verificationTypes = ["Select", "Document", "HOF"];
    List<String> cities = ["Select", "Ghaziabad", "Delhi"];
    List<String> districts = ["Select", "Ghaziabad", "Delhi"];
    List<String> seva = ["Select", "Ask Ghaziabad", "Ask Delhi"];
    List<String> states = ["Select", "Uttar Pradesh", "New Delhi", "Punjab"];
    List<String> addressProofs = ["Select", "Electricity Bill", "Bank Statement"];
    List<String> postOffices = ["Select", "Vaishali", "Bulandshahar"];
    List<String> villages = ["Select", "chithera", "Mohan Jedaro"];
    List<String> genders = ["Select", "Male", "Female", "Prefer not to say"];
    List<String> nameProofs = ["Select", "Bank Statement", "passport", "pan card"];
    List<String> birthProofs = ["Select", "birth Certificate", "passport", "Driving License"];
  


    List<String> check = [];

    if (widget.verificationType) {
      check = verificationTypes;
    } else if (widget.city) {
      check = cities;
    } else if (widget.stateSelect) {
      check = states;
    } else if (widget.sevaKendra) {
      check = seva;
    } else if (widget.nameProof) {
      check = nameProofs;
    } else if (widget.addressProof) {
      check = addressProofs;
    } else if (widget.birthProof) {
      check = birthProofs;
    } else if (widget.gender) {
      check = genders;
    } else if (widget.village) {
      check = villages;
    } else if (widget.postOffice) {
      check = postOffices;
    } else if (widget.district) {
      check = districts;
    }

    return DropdownButton<String>(
      isExpanded: true,
      value: dropdownValue,
      elevation: 16,
      style: const TextStyle(color: Colors.black),
      underline: Container(
        height: 1,
        color: Colors.black,
      ),
      onChanged: (String? newValue) {
        setState(() {
          dropdownValue = newValue!;
          widget.selected = dropdownValue;

        });
      },
      items: check.map<DropdownMenuItem<String>>(
        (String value) {
          return DropdownMenuItem<String>(
            value: value,
            child: Text(value),
          );
        },
      ).toList(),
    );
  }
}
