import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter/foundation.dart';

class ReusableTextField extends StatelessWidget {
  final TextEditingController controller;
  final bool isContact;
  final bool isOTP;

  const ReusableTextField({
    Key? key,
    required this.controller,
    this.isContact = false,
    this.isOTP = false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      obscureText: isOTP,
      maxLength: (isContact ? 10 : 6),
      keyboardType: defaultTargetPlatform == TargetPlatform.iOS
          ? const TextInputType.numberWithOptions(decimal: false, signed: false)
          : TextInputType.number,
      inputFormatters: [FilteringTextInputFormatter.digitsOnly],
      decoration: InputDecoration(
        hintStyle: const TextStyle(),
        border: OutlineInputBorder(
          borderSide: const BorderSide(color: Colors.black),
          borderRadius: BorderRadius.circular(13.0),
        ),
        hintText: (isContact ? "Enter Mobile No." : "Enter OTP"),
      ),
    );
  }
}
