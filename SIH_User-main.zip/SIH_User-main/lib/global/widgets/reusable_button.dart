import '../constants/colors.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bounce/flutter_bounce.dart';

class ReusableButton extends StatelessWidget {
  final Color? color;
  final String text;
  final Function onPressed;

  const ReusableButton({
    Key? key,
    this.color,
    required this.text,
    required this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Bounce(
      onPressed: () => onPressed(),
      duration: const Duration(milliseconds: 200),
      child: Container(
        height: 55.0,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(10.0),
          color: color,
          gradient: color == null ? kPrimaryGradient : null,
        ),
        child: Center(
          child: Text(
            text,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 20.0,
            ),
          ),
        ),
      ),
    );
  }
}
