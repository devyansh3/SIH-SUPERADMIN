enum UpdateItem {
  name,
  gender,
  phone,
  address,
  biometric,
  email,
}
