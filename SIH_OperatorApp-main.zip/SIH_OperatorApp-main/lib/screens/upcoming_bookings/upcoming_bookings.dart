import 'package:aadhar_operator/models/booking.dart';
import 'package:aadhar_operator/models/user.dart';
import 'package:aadhar_operator/screens/navigationBar/navigation_drawer.dart';
import 'package:aadhar_operator/screens/upcoming_bookings/widgets/booking_tile.dart';
import 'package:aadhar_operator/services/booking_service.dart';
import 'package:aadhar_operator/services/user_services.dart';
import 'package:flutter/material.dart';

class UpcomingBookingMainPage extends StatelessWidget {
  static const id = '/upcoming_bookings';
  const UpcomingBookingMainPage({Key? key}) : super(key: key);
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: const NavigationDrawer(),
      appBar:
      PreferredSize(
        preferredSize: const Size.fromHeight(60.0),

        child: AppBar(
          backgroundColor: Colors.black,
          title: Padding(
            padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
            child: Container (
             // margin: const EdgeInsets.only(top: 50.0),
              child:
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      //Image.asset("assets/uidai_english_logo.png",
                        //  width: 180, height: 60),
                      const Text(
                        "                            ",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 16.0,
                        ),
                      ),
                      Image.asset("assets/aadhar.png",
                          width: 70, height: 70),
                    ],
                  ),

                ],
              ),
            ),
          ),
        ),

      ),
      body: Builder(
          builder: (context) {
            return Center(
              child: SizedBox(
                child: Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const Divider(
                            thickness: 1,
                          ),
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [

                              IconButton(
                                onPressed: () =>
                                    Navigator.pushNamed(context, ""),
                                icon: const Icon(
                                  Icons.chevron_left,
                                  color: Colors.white,
                                  size: 24.0,
                                  semanticLabel: 'Back',
                                ),
                              ),
                              const Text(
                                  "Today's Schedule                               ",
                                  style: TextStyle(
                                    color: Colors.black,
                                    fontSize: 16.0,
                                  ),
                                ),

                            ],
                          ),

          ],
                      ),
                    ),
                    const SizedBox(height: 5.0,),
                    FutureBuilder<List<Booking>>(
                      future: BookingService().getTodaysSchedule(),
                      builder: (context, bookingSnapshot) {
                        if(!bookingSnapshot.hasData){
                          return const Center(child: CircularProgressIndicator());
                        }

                        return Expanded(
                          child: ListView.builder(
                            itemCount: bookingSnapshot.data!.length,
                            itemBuilder: (context, index) => FutureBuilder<Userr>(
                              future: UserService().getUserDetails(bookingSnapshot.data![index].userUid),
                              builder: (context, snapshot) {
                                // print(snapshot.data);
                                if(!snapshot.hasData){
                                  return Center(child:Text(bookingSnapshot.data![index].userUid));
                                }
                                return BookingTile(
                                  booking: bookingSnapshot.data![index],
                                  user:snapshot.data!
                                );
                              }
                            ),
                          ),
                        );
                      }
                    ),
                  ],
                ),
              ),

            );
          }

          ),

        );

      }
}
