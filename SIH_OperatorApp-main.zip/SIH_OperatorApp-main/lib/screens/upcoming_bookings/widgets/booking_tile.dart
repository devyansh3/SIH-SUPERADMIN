import 'package:aadhar_operator/global/constants/colors.dart';
import 'package:aadhar_operator/global/constants/slots.dart';
import 'package:aadhar_operator/models/booking.dart';
import 'package:aadhar_operator/models/user.dart';
import 'package:aadhar_operator/screens/booking_view/booking_view.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher_string.dart';

class BookingTile extends StatelessWidget {
  final Booking booking;
  final Userr user;
  const BookingTile({Key? key, required this.booking, required this.user}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final Color color1 = booking.status == 'Pending' ? Colors.white :
                          booking.status=='In Progress' ? Colors.lime :
                           booking.status=='Rescheduled' ? Colors.redAccent : Colors.grey ;
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: kDarkBlue),
        borderRadius: BorderRadius.circular(10.0),
        color: color1,
      ),
      child: ListTile(
        title: Text(slots[booking.timeSlot]?? "not defined"),
        subtitle: Text(booking.status),
        trailing: Wrap(
          spacing: 12, // space between two icons
          children: <Widget>[
             Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            // if (booking.flag == 'Booked') ...[
              IconButton(
                onPressed: () => launchUrlString('tel://${user.phone}'),
                icon: const Icon(
                  Icons.call,
                  color: Colors.black,
                ),
              ),
              IconButton(
                onPressed: () {
                  showModalBottomSheet(
                    context: context,
                    backgroundColor: Colors.transparent,
                    isScrollControlled: true,
                    builder: (context) => BookingView(booking, user),
                  );
                },
                icon: const Icon(
                  Icons.chevron_right,
                  size: 35.0,
                  color: Colors.black,
                ),
              ),
            ] ,
            // ]
      ) ],
      )
    ),);
  }
}
