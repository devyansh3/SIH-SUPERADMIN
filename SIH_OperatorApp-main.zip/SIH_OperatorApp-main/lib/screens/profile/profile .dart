import 'package:aadhar_operator/models/operator.dart';
import 'package:aadhar_operator/screens/profile/widget/numbers_widget.dart';
import 'package:aadhar_operator/screens/profile/widget/profile_widget.dart';
import 'package:aadhar_operator/services/operator_service.dart';
import 'package:flutter/material.dart';

import '../navigationBar/navigation_drawer.dart';

class ProfilePage extends StatefulWidget {
  static const id = '/profile_view';
  const ProfilePage({Key? key}) : super(key: key);

  @override
  ProfilePageState createState() => ProfilePageState();
}

class ProfilePageState extends State<ProfilePage> {
  @override
  Widget build(BuildContext context) {
    // final user = .myUser;
        var imageUrl = "https://firebasestorage.googleapis.com/v0/b/aadhaar-obs.appspot.com/o/profile_photos%2F360_F_346839683_6nAPzbhpSkIpb8pmAwufkC7c5eD7wYws.jpg?alt=media&token=b91ee552-8a14-4c13-87b6-2e46d2cb32d3";
    return Scaffold(
      drawer: const NavigationDrawer(),
      appBar: AppBar(
        title: const Text('Profile Page'),
        centerTitle: true,
        backgroundColor: Colors.black,
      ),
      body: FutureBuilder<Operator>(
        future: OperatorService().getOperatorDetails(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return const Center(child: (CircularProgressIndicator()));
          }
          return ListView(
            physics: const BouncingScrollPhysics(),
            children: [
              ProfileWidget(
                imagePath: snapshot.data!.imagePath == ""? imageUrl:snapshot.data!.imagePath,
                onClicked: () async {},
              ),
              const SizedBox(height: 24),
              buildName(snapshot.data!),
              const SizedBox(height: 24),
              const NumbersWidget(),
              const SizedBox(height: 48),
              buildAbout(snapshot.data!),
            ],
          );
        },
      ),
    );
  }

  Widget buildName(Operator user) => Column(
        children: [
          Text(
            user.name,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 24),
          ),
          const SizedBox(height: 4),
          Text(
            user.email,
            style: const TextStyle(color: Colors.grey),
          )
        ],
      );

  Widget buildAbout(Operator user) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 48),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Role',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 16),
            Text(
              user.role,
              style: const TextStyle(fontSize: 16),
            ),
            const Text(
              'Age',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Text(
              user.age.toString(),
              style: const TextStyle(fontSize: 16, height: 1.4),
            ),
            const Text(
              'Phone Number',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Text(
              user.phone.toString(),
              style: const TextStyle(fontSize: 16, height: 1.4),
            ),
            const Text(
              'Gender',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 20),
            Text(
              user.gender,
              style: const TextStyle(fontSize: 16, height: 1.4),
            ),
          ],
        ),
      );
}
