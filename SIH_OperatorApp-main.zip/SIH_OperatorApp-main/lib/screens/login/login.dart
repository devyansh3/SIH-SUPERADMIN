import 'package:aadhar_operator/global/widgets/reusable_button.dart';
import 'package:aadhar_operator/global/widgets/reusable_text_field.dart';
import 'package:flutter/material.dart';
import 'package:aadhar_operator/services/authenticator.dart';
import 'package:provider/provider.dart';

class LoginScreen extends StatefulWidget {
  static const id = '/login_screen';

  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController usernameController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  // Authservice authservice = Authservice();
  @override
  // void initState() {
  //   super.initState();
  //   usernameController = TextEditingController();
  //   passwordController = TextEditingController();
  // }

  @override
  void dispose() {
    super.dispose();
    usernameController.dispose();
    passwordController.dispose();
  }

   void loginUser() {
    context.read<FirebaseAuthMethods>().loginWithEmail(
          email: usernameController.text,
          password: passwordController.text,
          context: context,
        );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              Image.asset('assets/aadhar.png'),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                child: ReusableTextField(
                  controller: usernameController,
                  hintText: 'Enter Operator ID',
                ),
              ),
              const SizedBox(height: 20),
              Container(
                margin: const EdgeInsets.symmetric(horizontal: 20),
                child: ReusableTextField(
                  controller: passwordController,
                  hintText: 'Enter your password',
                  isPassword: true,
                ),
              ),
              const SizedBox(height: 20),
              ReusableButton(
                text: 'LOG IN',
                onPressed: () {
                  loginUser();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}
