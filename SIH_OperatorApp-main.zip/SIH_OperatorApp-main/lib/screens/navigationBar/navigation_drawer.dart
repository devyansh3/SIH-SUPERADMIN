import 'package:aadhar_operator/models/operator.dart';
import 'package:aadhar_operator/screens/navigationBar/drawer_item.dart';
import 'package:aadhar_operator/screens/profile/profile%20.dart';
import 'package:aadhar_operator/screens/upcoming_bookings/upcoming_bookings.dart';
import 'package:aadhar_operator/services/authenticator.dart';
import 'package:aadhar_operator/services/operator_service.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


import '../settings/setting.dart';

class NavigationDrawer extends StatelessWidget {
  const NavigationDrawer({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Material(
        color: Colors.black,
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24.0, 80, 24, 0),
          child: Column(
            children: [
              headerWidget(),
              const SizedBox(
                height: 40,
              ),
              const Divider(
                thickness: 1,
                height: 10,
                color: Colors.grey,
              ),
              const SizedBox(
                height: 40,
              ),
              DrawerItem(
                name: 'My Account',
                icon: Icons.account_box_rounded,
                onPressed: () => onItemPressed(context, index: 0),
              ),
              const SizedBox(
                height: 30,
              ),
              DrawerItem(
                  name: '''Today's Schedule ''',
                  icon: Icons.schedule,
                  onPressed: () => onItemPressed(context, index: 1)),
              const SizedBox(
                height: 30,
              ),
            /*  DrawerItem(
                  name: 'Calendar',
                  icon: Icons.calendar_month,
                  onPressed: () => onItemPressed(context, index: 2)),
              const SizedBox(
                height: 30,
              ),
*/
              const Divider(
                thickness: 1,
                height: 10,
                color: Colors.grey,
              ),
              const SizedBox(
                height: 30,
              ),
              DrawerItem(
                  name: 'Settings',
                  icon: Icons.settings,
                  onPressed: () => onItemPressed(context, index: 4)),
              const SizedBox(
                height: 30,
              ),
              DrawerItem(
                  name: 'Log out',
                  icon: Icons.logout,
                  onPressed: () => onItemPressed(context, index: 5)),
            ],
          ),
        ),
      ),
    );
  }

  void onItemPressed(BuildContext context, {required int index}) {
    // Navigator.pop(context);

    switch (index) {
      case 0:
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const ProfilePage()));
        break;
      case 1:
        Navigator.push(
            context,
            MaterialPageRoute(
                builder: (context) => const UpcomingBookingMainPage()));
        break;

      case 4:
        Navigator.push(context,
            MaterialPageRoute(builder: (context) => const SettingsPage()));
        break;
      case 5:
        context.read<FirebaseAuthMethods>().signOut(context);
        break;
    }
  }

  Widget headerWidget() {
        const imageUrl = "https://firebasestorage.googleapis.com/v0/b/aadhaar-obs.appspot.com/o/profile_photos%2F360_F_346839683_6nAPzbhpSkIpb8pmAwufkC7c5eD7wYws.jpg?alt=media&token=b91ee552-8a14-4c13-87b6-2e46d2cb32d3";
        return FutureBuilder<Operator>(
        future: OperatorService().getOperatorDetails(),
        builder: (context, snapshot) {

        if(!snapshot.hasData){
          return const Center(child:(CircularProgressIndicator()));
        }
        final imagePath =  snapshot.data!.imagePath == ""? imageUrl:snapshot.data!.imagePath;

        return Row(
          children: [
            const CircleAvatar(
              radius: 40,
              backgroundImage: NetworkImage(imageUrl),
            ),

            const SizedBox(
              width: 20,
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(snapshot.data!.name,
                    style: const TextStyle(fontSize: 14, color: Colors.white)),
                const SizedBox(
                  height: 10,
                ),
                Text(snapshot.data!.email,
                    style: const TextStyle(fontSize: 14, color: Colors.white)),
                const SizedBox(
                  height: 10,
                ),
                Text('Rating : ${snapshot.data!.rating.avg}',
                    style: const TextStyle(fontSize: 14, color: Colors.white)),
              ],
            )
          ],
        );
      }
    );
  }
}
