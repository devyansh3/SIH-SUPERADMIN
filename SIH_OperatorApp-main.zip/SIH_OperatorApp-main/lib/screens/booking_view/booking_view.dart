import 'package:aadhar_operator/models/booking.dart';
import 'package:aadhar_operator/models/user.dart';
import 'package:aadhar_operator/screens/booking_view/widgets/booking_prop.dart';
import 'package:flutter/material.dart';
import 'package:maps_launcher/maps_launcher.dart';
import 'package:slide_to_confirm/slide_to_confirm.dart';
import 'package:url_launcher/url_launcher_string.dart';
import 'package:flutter_sms/flutter_sms.dart';
import '../../global/widgets/reusable_button.dart';
import '../../services/booking_service.dart';
import '../upcoming_bookings/upcoming_bookings.dart';

import 'package:telephony/telephony.dart';

class BookingView extends StatefulWidget {
  final Booking booking;
  final Userr user;
  const BookingView(this.booking, this.user ,{Key? key}) : super(key: key);

  @override
  BookingViewState createState() => BookingViewState();
}

class BookingViewState extends State<BookingView> {
  final Telephony telephony = Telephony.instance;
  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;

    return Container(
      height: size.height * 0.75,
      margin: const EdgeInsets.all(20.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10.0),
        color: Colors.white,
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          Column(
            children: [
              BookingProp(
                  content: widget.user.name,
                  color: const Color.fromRGBO(185, 220, 255, 0.5)),
              BookingProp(
                content: widget.user.phone,
                color: const Color.fromRGBO(185, 220, 255, 0.5),
                actionButton: IconButton(
                  onPressed: () =>
                      launchUrlString('tel://${widget.user.phone}'),
                  icon: const CircleAvatar(
                    radius: 25.0,
                    child: Icon(Icons.phone),
                  ),
                ),
              ),
              BookingProp(
                content: widget.user.address.toString(),
                color: const Color.fromRGBO(185, 220, 255, 0.5),
                actionButton: IconButton(
                  onPressed: () =>
                      MapsLauncher.launchCoordinates(widget.user.address.lat, widget.user.address.lng),
                  icon: const CircleAvatar(
                    radius: 25.0,
                    child: Icon(Icons.directions),
                  ),
                ),
              ),
              BookingProp(
                content: widget.booking.slotDate,
                // DateFormat('MMMM d, y \nh : m a')
                //     .format(widget.booking.dateTime),
                color: const Color.fromRGBO(185, 220, 255, 0.5),
                actionButton: IconButton(
                  onPressed: () {},
                  icon: const CircleAvatar(
                    radius: 30.0,
                    child: Icon(Icons.calendar_month),
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.all(20.0),
                child: Row(children: [
                  if (widget.booking.status == 'Closed') ...[
                    Container(
                      width: 300.0,
                      height: 55.0,
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: Colors.blue,
                        ),
                        borderRadius: BorderRadius.circular(10.0),
                      ),
                      child: const Center(
                        child: Text(
                          'Application Closed',
                          style: TextStyle(fontSize: 18, color: Colors.black),
                        ),
                      ),
                    ),
                  ] else if (widget.booking.status == 'In Progress') ...[
                    Row(
                      children: [
                        const SizedBox(
                          width: 10,
                        ),
                        ReusableButton(
                          text: '  Completed  ',
                          onPressed: () {
                            BookingService().setStatus("Closed", widget.booking.uid);
                            BookingService().setTracking(false,widget.booking.uid);
                            Navigator.push(
                                context,
                                MaterialPageRoute(
                                    builder: (context) =>
                                        const UpcomingBookingMainPage()));
                          },
                        ),
                        const SizedBox(
                          width: 45,
                        ),
                        ReusableButton(
                          text: '  '
                              'Reschedule  ',
                          onPressed: () {
                            BookingService().setStatus("Incomplete Application", widget.booking.uid);
                            BookingService().setTracking(false,widget.booking.uid);
                            showDialog(
                              context: context,
                              builder: (BuildContext context) =>
                                  _buildPopupDialog(context),
                            );
                          },
                        ),
                      ],
                    )

                  ] else ...[
                    /*  Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: <Widget>[
                            GestureDetector(
                              onPanStart: (DragStartDetails details) {
                                initial = details.globalPosition.dx;
                              },
                              onPanUpdate: (DragUpdateDetails details) {
                                double distance = details.globalPosition.dx - initial;
                                double percentageAddition = distance / 200;
                                setState(() {
                                  percentage = (percentage + percentageAddition).clamp(0.0, 100.0);  }
                                );
                              },
                              onPanEnd: (DragEndDetails details) { initial = 0.0;  },
                              child: CustomSlider(
                                  percentage: percentage,
                                  positiveColor: postitiveColor,
                                  negetiveColor: negetiveColor,
                              ),)
                        ],),),
*/

                    Center(
                      child: Column(
                        children: [
                          Row( children: [
                            ConfirmationSlider(
                              backgroundShape: BorderRadius.circular(10.0),
                              foregroundShape: BorderRadius.circular(10.0),
                              width: 300.0,
                              height: 55.0,
                              text: 'Start appointment',
                              textStyle:
                              const TextStyle(fontSize: 18, color: Colors.black),
                              onConfirmation: () {
                                MapsLauncher.launchCoordinates(widget.user.address.lat, widget.user.address.lng);
                                BookingService().setStatus("In Progress", widget.booking.uid);
                                BookingService().setTracking(true, widget.booking.uid);
                                Navigator.push(context,
                                    MaterialPageRoute(
                                        builder: (context) => const UpcomingBookingMainPage()));
                                //_sendSMS("Your appointment has started ", recipients);
                              },
                            ),
    ]

                          ),
                          Row(
                            children: const [
                              SizedBox(
                                height: 20,
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              ReusableButton(
                                text: '  Reschedule  ',
                                onPressed: () {
                                  BookingService().setStatus("Rescheduled", widget.booking.uid);
                                  BookingService().setTracking(false, widget.booking.uid);
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) =>
                                          const UpcomingBookingMainPage()));

                                  showDialog(
                                    context: context,
                                    builder: (BuildContext context) =>
                                        _buildRescheduleDialog(context),
                                  );
                                  },
                              ),
                            ],
                          )
                        ],
                      )
                    )


                  ]
                ]),
              ),
            ],
          ),
        ],
      ),
    );
  }
}


void _sendSMS(String message, List<String> recipients) async {
  String result = await sendSMS(message: message, recipients: recipients)
      .catchError((onError) {
    print(onError);
  });
  print(result);
}



Widget _buildRescheduleDialog(BuildContext context) {
  return AlertDialog(
    title: const Text('Select Reason to Reschedule appointment '),
    content: Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: const <Widget>[
        RadioRescheduleWidget(),
        SizedBox(
          width: 480.0,
          child: TextField(
            decoration: InputDecoration(),
          ),
        )
      ],
    ),
    actions: <Widget>[
      FlatButton(
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => const UpcomingBookingMainPage()));
        },
        textColor: Theme.of(context).primaryColor,
        child: const Text('Submit'),
      ),
    ],
  );
}


Widget _buildPopupDialog(BuildContext context) {
  return AlertDialog(
    title: const Text('Select Reason to Reschedule appointment '),
    content: Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: const <Widget>[
        RadioButtonWidget(),  
        SizedBox(
          width: 480.0,
          child: TextField(
            decoration: InputDecoration(),
          ),
        )
      ],
    ),
    actions: <Widget>[
      FlatButton(
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => const UpcomingBookingMainPage()));
        },
        textColor: Theme.of(context).primaryColor,
        child: const Text('Submit'),
      ),
    ],
  );
}

enum SingingCharacter { documents, user, health, other }

List<String> recipients = ["9810379103"];

class RadioButtonWidget extends StatefulWidget {
  const RadioButtonWidget({Key? key}) : super(key: key);

  @override
  State<RadioButtonWidget> createState() => _RadioButtonWidgetState();
}

class _RadioButtonWidgetState extends State<RadioButtonWidget> {
  SingingCharacter? _character = SingingCharacter.documents;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[

        ListTile(
          title: const Text('Incomplete Documents '),
          leading: Radio<SingingCharacter>(
            value: SingingCharacter.documents,
            groupValue: _character,
            onChanged: (SingingCharacter? value) {
              setState(() {
                _character = value;
              });
            },
          ),
        ),
        ListTile(
          title: const Text('User not available '),
          leading: Radio<SingingCharacter>(
            value: SingingCharacter.user,
            groupValue: _character,
            onChanged: (SingingCharacter? value) {
              setState(() {
                _character = value;
              });
            },
          ),
        ),
        ListTile(
          title: const Text('Personal/ Health emergency '),
          leading: Radio<SingingCharacter>(
            value: SingingCharacter.health,
            groupValue: _character,
            onChanged: (SingingCharacter? value) {
              setState(() {
                _character = value;
              });
            },
          ),
        ),
        ListTile(
          title: const Text('Other Reason '),
          leading: Radio<SingingCharacter>(
            value: SingingCharacter.other,
            groupValue: _character,
            onChanged: (SingingCharacter? value) {
              setState(() {
                _character = value;
              });
            },
          ),
        ),
      ],
    );
  }
}


enum RescheduleOp { transport, health, other }
class RadioRescheduleWidget extends StatefulWidget {
  const RadioRescheduleWidget({Key? key}) : super(key: key);

  @override
  State<RadioRescheduleWidget> createState() => _RadioRescheduleWidgetState();
}

class _RadioRescheduleWidgetState extends State<RadioRescheduleWidget> {
  RescheduleOp? _char = RescheduleOp.transport;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[

        ListTile(
          title: const Text('Transport failure '),
          leading: Radio<RescheduleOp>(
            value: RescheduleOp.transport,
            groupValue: _char,
            onChanged: (RescheduleOp? value) {
              setState(() {
                _char = value;
              });
            },
          ),
        ),
        ListTile(
          title: const Text('Personal/ Health emergency '),
          leading: Radio<RescheduleOp>(
            value: RescheduleOp.health,
            groupValue: _char,
            onChanged: (RescheduleOp? value) {
              setState(() {
                _char = value;
              });
            },
          ),
        ),
        ListTile(
          title: const Text('Other Reason '),
          leading: Radio<RescheduleOp>(
            value: RescheduleOp.other,
            groupValue: _char,
            onChanged: (RescheduleOp? value) {
              setState(() {
                _char = value;
              });
            },
          ),
        ),
      ],
    );
  }
}
class CustomSlider extends StatelessWidget {
  double totalWidth = 200.0;
  double percentage;
  Color positiveColor;
  Color negetiveColor;

  CustomSlider(
      {required this.percentage,
      required this.positiveColor,
      required this.negetiveColor});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: totalWidth + 4.0,
      height: 30.0,
      decoration: BoxDecoration(
          color: negetiveColor,
          border: Border.all(color: Colors.black, width: 2.0)),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          Container(
            color: positiveColor,
            width: (percentage / 100) * totalWidth,
          ),
        ],
      ),
    );
  }
}
