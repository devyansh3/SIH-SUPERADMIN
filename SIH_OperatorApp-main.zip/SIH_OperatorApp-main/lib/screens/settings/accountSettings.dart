// import 'package:aadhar_operator/models/user.dart';
import 'package:babstrap_settings_screen/babstrap_settings_screen.dart';
// import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class AccountSettingsPage extends StatefulWidget {
  const AccountSettingsPage({Key? key}) : super(key: key);

  @override
  _AccountSettingPageState createState() => _AccountSettingPageState();
}


class _AccountSettingPageState extends State<AccountSettingsPage> {

//  User user = UserPreferences.myUser;
  final languages = ['English', 'Hindi', 'Tamil', 'Telugu'];
  String dropdownvalue = 'English';
  // User user = UserPreferences.myUser;
  bool _value1 = false;
  bool _value2 = false;
  bool _value3 = false;
  bool _value4 = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: //buildAppBar(context),
      AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Account Settings'),
        centerTitle: true,
        backgroundColor: Colors.black,
      ),
      body:
      Padding(
        padding: const EdgeInsets.all(20),
        child: ListView(
          children: [
            buildLanguage(),
          ],
        ),
      ),
    );

  }

  Widget buildLanguage() => Row(
    children: [
      Text(
        "Language",
        style: TextStyle(fontWeight: FontWeight.w500, fontSize: 18),
      ),
      SizedBox(width: 140.0),
      DropdownButton(
        value: dropdownvalue,
        icon: Icon(Icons.keyboard_arrow_down),
        items:languages.map((String items) {
          return DropdownMenuItem(
              value: items,
              child: Text(items)
          );
        }).toList(),
        onChanged: (String? value) {  },

      ),
    ],
  );
}