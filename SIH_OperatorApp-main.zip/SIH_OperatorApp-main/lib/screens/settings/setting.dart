import 'package:aadhar_operator/screens/settings/accountSettings.dart';
import 'package:aadhar_operator/screens/settings/notification.dart';
import 'package:babstrap_settings_screen/babstrap_settings_screen.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

import '../navigationBar/navigation_drawer.dart';

class SettingsPage extends StatefulWidget {
  const SettingsPage({Key? key}) : super(key: key);

  @override
  SettingPageState createState() => SettingPageState();
}


class SettingPageState extends State<SettingsPage> {

  // final user = DatabaseService.getOperatorDetails();
  bool _value = false;

  @override
  Widget build(BuildContext context) {

    return Scaffold(
      drawer: const NavigationDrawer(),
      appBar: //buildAppBar(context),
      AppBar(
        title: const Text('Settings Page'),
        centerTitle: true,
        backgroundColor: Colors.black,
      ),
      body:
      Padding(
        padding: const EdgeInsets.all(10),
        child: ListView(
          children: [
            //
            SettingsGroup(
              items: [
                SettingsItem(
                  onTap: () {Navigator.push(context, MaterialPageRoute(builder: (context) => const AccountSettingsPage()));},
                  icons: CupertinoIcons.pencil_outline,
                  iconStyle: IconStyle(),
                  title: 'Account Settings',
                  subtitle: "Privacy, Security, Language",
                ),
                SettingsItem(
                  onTap: () {Navigator.push(context, MaterialPageRoute(builder: (context) => const NotificationsPage()));},
                  icons: Icons.circle_notifications_rounded,
                  iconStyle: IconStyle(
                    iconsColor: Colors.white,
                    withBackground: true,
                    backgroundColor: Colors.lightGreen,
                  ),
                  title: 'Notification',
                  subtitle: "Newsletter, App updates",
                ),
                SettingsItem(
                  onTap: () {},
                  icons: Icons.dark_mode_rounded,
                  iconStyle: IconStyle(
                    iconsColor: Colors.white,
                    withBackground: true,
                    backgroundColor: Colors.indigo,
                  ),
                  title: 'Dark mode',
                  subtitle: "Automatic",
                  trailing: Switch.adaptive(
                    value: _value,
                    onChanged: (newValue) => setState(() => _value = newValue),
                  ),
                ),
              ],
            ),
            SettingsGroup(
              items: [
                SettingsItem(
                  onTap: () {},
                  icons: Icons.logout_rounded,
                  iconStyle: IconStyle(
                    backgroundColor: Colors.purple,
                  ),
                  title: 'Sign Out',
                  subtitle: "Logout / Delete account",
                ),
              ],
            ),
            // You can add a settings title
            SettingsGroup(
              settingsGroupTitle: "Feedback",
              items: [
                SettingsItem(
                  onTap: () {},
                  icons: Icons.bug_report_rounded,
                  title: "Report a bug",
                ),
                SettingsItem(
                  onTap: () {},
                  icons: CupertinoIcons.repeat,
                  title: "Change email",
                ),
                SettingsItem(
                  onTap: () {},
                  icons: CupertinoIcons.hand_thumbsup,
                  title: "Send Feedback",
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

}