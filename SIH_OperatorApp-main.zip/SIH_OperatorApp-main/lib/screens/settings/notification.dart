import 'package:babstrap_settings_screen/babstrap_settings_screen.dart';
import 'package:flutter/material.dart';

class NotificationsPage extends StatefulWidget {
  const NotificationsPage({Key? key}) : super(key: key);

  @override
  NotificationPageState createState() => NotificationPageState();
}

class NotificationPageState extends State<NotificationsPage> {
  // final user = UserPreferences.myUser;
  bool _value1 = false;
  bool _value2 = false;
  bool _value3 = false;
  bool _value4 = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: //buildAppBar(context),
          AppBar(
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: Colors.white),
          onPressed: () => Navigator.of(context).pop(),
        ),
        title: const Text('Notifications Page'),
        centerTitle: true,
        backgroundColor: Colors.black,
      ),
      body: Padding(
        padding: const EdgeInsets.all(10),
        child: ListView(
          children: [
            SettingsGroup(
              items: [
                SettingsItem(
                  onTap: () {},
                  icons: Icons.message,
                  iconStyle: IconStyle(
                    iconsColor: Colors.white,
                    withBackground: true,
                    backgroundColor: Colors.deepPurpleAccent,
                  ),
                  title: 'News for you',
                  trailing: Switch.adaptive(
                    value: _value1,
                    onChanged: (newValue) => setState(() => _value1 = newValue),
                  ),
                ),
              ],
            ),
            SettingsGroup(
              items: [
                SettingsItem(
                  onTap: () {},
                  icons: Icons.person,
                  iconStyle: IconStyle(
                    iconsColor: Colors.white,
                    withBackground: true,
                    backgroundColor: Colors.amber,
                  ),
                  title: 'Account Activity',
                  trailing: Switch.adaptive(
                    value: _value2,
                    onChanged: (newValue) => setState(() => _value2 = newValue),
                  ),
                ),
              ],
            ),
            SettingsGroup(
              items: [
                SettingsItem(
                  onTap: () {},
                  icons: Icons.newspaper_rounded,
                  iconStyle: IconStyle(
                    iconsColor: Colors.white,
                    withBackground: true,
                    backgroundColor: Colors.purple,
                  ),
                  title: 'Newsletter',
                  trailing: Switch.adaptive(
                    value: _value3,
                    onChanged: (newValue) => setState(() => _value3 = newValue),
                  ),
                ),
              ],
            ),
            SettingsGroup(
              items: [
                SettingsItem(
                  onTap: () {},
                  icons: Icons.update,
                  iconStyle: IconStyle(
                    iconsColor: Colors.white,
                    withBackground: true,
                    backgroundColor: Colors.blueGrey,
                  ),
                  title: 'App updates',
                  trailing: Switch.adaptive(
                    value: _value4,
                    onChanged: (newValue) => setState(() => _value4 = newValue),
                  ),
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}
