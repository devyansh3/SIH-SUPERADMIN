// import 'dart:js';

import 'package:aadhar_operator/models/operator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UserService{
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<Operator> getUserDetails() async{
    print(_auth.currentUser?.email);
    // try{
      var userData = await _firestore
                .collection('user')
                .where('UID', isEqualTo: _auth.currentUser?.uid)
                .get();
      print(userData);
      return userData.docs.map((snap) => Operator.fromMap(snap)).toList()[0];

    // }catch(e){
    //   print(e);
    // }
  }
}