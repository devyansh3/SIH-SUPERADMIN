// import 'dart:js';

import 'package:aadhar_operator/models/user.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class UserService{
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<Userr> getUserDetails(String uid) async{
    // print(_auth.currentUser?.email);
    // try{
      var userData = await _firestore
                .collection('users')
                .where('uid', isEqualTo: uid)
                .get();
      print(userData.docs[0].data());
      return userData.docs.map((snap) => Userr.fromMap(snap)).toList()[0];

    // }catch(e){
    //   print(e);
    // }
  }
}