// import 'dart:js';

import 'package:aadhar_operator/models/operator.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';

class OperatorService{
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<Operator> getOperatorDetails() async{
    print(_auth.currentUser?.email);
      var userData = await _firestore
                .collection('operators')
                .where('email', isEqualTo: _auth.currentUser?.email)
                .get();
      return userData.docs.map((snap) => Operator.fromMap(snap)).toList()[0];

  }

}