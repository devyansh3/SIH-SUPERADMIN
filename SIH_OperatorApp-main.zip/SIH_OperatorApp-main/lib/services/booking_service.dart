import 'package:aadhar_operator/models/booking.dart';
import 'package:aadhar_operator/services/operator_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:intl/intl.dart';

class BookingService{
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  final OperatorService _curroperator = OperatorService();

  
  Future<List<Booking>> getTodaysSchedule() async{
    // print(_auth.currentUser?.email);
    // try{
      // print(DateTime.now());
      var curr = await _curroperator.getOperatorDetails();
      // print(curr.uid);
      // print(curr.email);
      String  date = DateFormat('dd/MM/yyyy').format(DateTime.now());

      var userData = await _firestore
                .collection('operators').doc(curr.uid.trim()).collection('bookings')
                .where('date', isEqualTo: date)
                .get();
      // print(userData.docs[0]);
      // print(userData.docs[1]);
      // List<Booking> bookings =[];
      return (userData.docs.map((snap) => Booking.fromMap(snap)).toList());
  }

  void setStatus(String newValue, String uid) async {
    var curr = await _curroperator.getOperatorDetails();
    var userData = await _firestore
        .collection('operators').doc(curr.uid.trim()).collection('bookings').doc(uid).update({'status':newValue});

  }
  void setTracking(bool newValue, String uid) async {
    var curr = await _curroperator.getOperatorDetails();
    var userData = await _firestore
        .collection('operators').doc(curr.uid.trim()).collection('bookings').doc(uid).update({'tracking':newValue});

  }
}