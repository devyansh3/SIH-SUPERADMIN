// import 'package:aadhar_operator/models/operator.dart';

// class UserPreferences {
//   static const myUser = Operator(
//     imagePath:
//     'https://images.saymedia-content.com/.image/ar_1:1%2Cc_fill%2Ccs_srgb%2Cfl_progressive%2Cq_auto:eco%2Cw_1200/MTc2MjQ3ODcxNTQ3NDUwNzkz/list-of-mr-bean-movies-rowan-atkinson-the-funny-man.jpg',
//     name: 'Mr Bean',
//     email: 'mr.Bean@gmail.com',
//     role: 'Biometric update operator',
//      age: 38,
//      phone: 9999999999,
//      gender: 'Male',
//      isDarkMode: false,
//   );
// }