import 'package:flutter/material.dart';

const kPrimaryGradient = LinearGradient(
  colors: [
    Color(0xFF020e51),
    Color(0xFF18aedb),
  ],
);

const kDarkBlue = Color(0xFF020e51);

const kLightBlue = Color(0xFF18aedb);

const kDisabledColor = Colors.grey;
