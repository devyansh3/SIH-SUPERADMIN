import 'package:aadhar_operator/providers/operator_provider.dart';
import 'package:aadhar_operator/screens/login/authentication.dart';
import 'package:aadhar_operator/screens/login/login.dart';
import 'package:aadhar_operator/screens/upcoming_bookings/upcoming_bookings.dart';
import 'package:aadhar_operator/services/authenticator.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import 'package:get/get.dart';
import 'firebase_options.dart';
/*
import 'package:flutter/material.dart';import 'package:flutter/material.dart';
import 'dart:async';
import 'package:telephony/telephony.dart';
backgrounMessageHandler(SmsMessage message) async {
  Telephony.backgroundInstance.sendSms(to: "9810379103", message: "Message from background")
}

void main() {
  runApp(MyApp());
}

class MyApp extends StatefulWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  _MyAppState createState() => _MyAppState();
}
class _MyAppState extends State<MyApp> {
  final telephony = Telephony.instance;

  @override
  void initState() {
    super.initState();
    final inbox = telephony.getInboxSms();
  }

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    throw UnimplementedError();
  }
}*/
void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  runApp(const MyApp());
}
class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
        providers: [
          Provider<FirebaseAuthMethods>(
            create: (_) => FirebaseAuthMethods(FirebaseAuth.instance),
          ),
          StreamProvider(
            create: (context) => context.read<FirebaseAuthMethods>().authState,
            initialData: null,
          ),
          ChangeNotifierProvider<OperatorProvider>(
            create: (context)=>OperatorProvider()
          ),
          // StreamProvider(create: (context)=> context.read<OperatorService>().getOperatorDetails(): initialData)

        ],
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          home: const AuthWrapper(),
          routes: {
            LoginScreen.id: (context) => const LoginScreen(),
            AuthenticationPage.id: (context) => const AuthenticationPage(),
            UpcomingBookingMainPage.id: (context) =>
                const UpcomingBookingMainPage(),
          },
        ));
  }
}

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final firebaseUser = context.watch<User?>();

    if (firebaseUser != null) {
      return const UpcomingBookingMainPage();
    }
    return const LoginScreen();
  }
}


