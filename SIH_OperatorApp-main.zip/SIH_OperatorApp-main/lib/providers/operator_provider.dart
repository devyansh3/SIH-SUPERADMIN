import 'package:flutter/material.dart';

import 'package:aadhar_operator/models/operator.dart';
import 'package:aadhar_operator/services/operator_service.dart';


class OperatorProvider extends ChangeNotifier{
  // ?\final OperatorService _databaseService = OperatorService();

  Future<Operator> currentOperator = OperatorService().getOperatorDetails();
  
  Future<Operator> get currentOperatorData {
    return currentOperator;
  }
  
}