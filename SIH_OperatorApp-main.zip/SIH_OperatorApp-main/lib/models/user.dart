import 'package:cloud_firestore/cloud_firestore.dart';

class Address{
  final String city;
  final double lat;
  final double lng;
  final String state;
  final String addressLine;

  const Address({
    required this.city,
    required this.lat,
    required this.lng,
    required this.state,
    required this.addressLine
  });

  Map<String,dynamic> toMap(){
    return{
      'city':city,
      'lat':lat,
      'lng':lng,
      'state': state,
      'address_line':addressLine
    };
  }

  Address.fromMap(Map<String,dynamic> addressMap)
      :city = addressMap['city'],
        lat = addressMap['lat'],
        lng = addressMap['lng'],
        state = addressMap['state'],
        addressLine = addressMap['address_line'];

  @override
  String toString() {
    return "$addressLine, $city, $state";
  }

}

class Userr {
  final String aadhaarNumber;
  final String ask;
  final String name;
  final String phone;
  final int requestType;
  final bool residentOfIndia;
  final int signupTimestamp;
  final Address address;
  final String uid;

  const Userr({
    required this.aadhaarNumber,
    required this.ask,
    required this.name,
    required this.phone,
    required this.requestType,
    required this.residentOfIndia,
    required this.signupTimestamp,
    required this.address,
    required this.uid
  });

  Map<String, dynamic> toMap(){
    return {
      'name':name,
      'aadhaar_number':aadhaarNumber,
      'ask':ask,
      'phone':phone,
      'request_type':requestType,
      'resident_of_india':residentOfIndia,
      'address':address.toMap(),
      'uid':uid,
      'sighn_up_timestamp':signupTimestamp
    };
  }

  Userr.fromMap(DocumentSnapshot<Map<String,dynamic>> doc)
    : name = doc['name'],
      aadhaarNumber = doc['aadhaar_number'],
      ask = doc['ask'],
      phone = doc['phone'],
      requestType = doc['request_type'],
      residentOfIndia = doc['resident_of_india'],
      address = Address.fromMap(doc.data()!['address']),
      signupTimestamp  = doc['sign_up_timestamp'],
      uid = doc['uid'];
}

