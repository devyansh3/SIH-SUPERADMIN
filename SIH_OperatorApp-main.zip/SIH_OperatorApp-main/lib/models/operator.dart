import 'package:cloud_firestore/cloud_firestore.dart';

class Rating{
  final int avg;
  final int sum;
  final int count;

  const Rating({
    required this.avg,
    required this.count,
    required this.sum
  });

  Map<String,dynamic> toMap(){
    return{
      'avg':avg,
      'sum':sum,
      'count':count
    };
  }

  Rating.fromMap(Map<String,dynamic> ratingMap)
    :avg = ratingMap['avg'],
    sum = ratingMap['sum'],
    count = ratingMap['count'];

}

class Operator {
  final String imagePath;
  final String name;
  final String email;
  final String role;
  final int age;
  final String phone;
  final String gender;
  final bool isDarkMode;
  final Rating rating;
  final String uid;
  final int slotsPerHour;
  final String ask;

  const Operator({
    required this.imagePath,
    required this.name,
    required this.email,
    required this.role,
    required this.age,
    required this.phone,
    required this.gender,
    required this.ask,
    required this.rating,
    required this.isDarkMode,
     required this.slotsPerHour,
    required this.uid
  });
  Map<String, dynamic> toMap(){
    return {
      'name':name,
      'age':age,
      'email':email,
      'role':role,
      'profile_img':imagePath,
      'phone':phone,
      'gender':gender,
      'is_dark':isDarkMode,
      'rating':rating.toMap(),
      'uid':uid,
      'slots_per_hour':slotsPerHour,
      'ask': ask,
    };
  }

  Operator.fromMap(DocumentSnapshot<Map<String,dynamic>> doc)
    : imagePath = doc['profile_img'],
      name = doc['name'],
      age = doc['age'],
      email = doc['email'],
      role = doc['role'],
      phone = doc['phone'],
      gender =  doc['gender'],
      rating = Rating.fromMap(doc.data()!['ratings']),
      isDarkMode  = doc['is_dark'],
      slotsPerHour = doc['slots_per_hour'],
      uid = doc['uid'],
      ask = doc['ask'];
}

