import 'package:cloud_firestore/cloud_firestore.dart';


class Booking {
  int bookingTime;
  String slotDate;
  String operatorUid;
  int remainingSlots;
  int requestType;
  int slotsPerHour;
  String status;
  int timeSlot;
  String uid;
  String userUid;
  bool tracking;

  Booking({
    required this.bookingTime,
    required this.slotDate,
    required this.operatorUid,
    required this.remainingSlots,
    required this.requestType,
    required this.slotsPerHour,
    required this.status,
    required this.timeSlot,
    required this.uid,
    required this.userUid,
    required this.tracking
  });

  // Booking copyWith({
  //   String ? flag,
  //   String ? slot,
  //   DateTime? dateTime,
  //   String? userPhone,
  //   String? userName,
  //   String? address,
  //   Location? location,
  //   String? status,
  //   List<UpdateItem>? updateItems,
  // }) {
  //   return Booking(
  //     flag: flag ?? this.flag,
  //     slot: slot ?? this.slot,
  //     dateTime: dateTime ?? this.dateTime,
  //     userPhone: userPhone ?? this.userPhone,
  //     userName: userName ?? this.userName,
  //     address: address ?? this.address,
  //     location: location ?? this.location,
  //     status: status ?? this.status,
  //     updateItems: updateItems ?? this.updateItems,
  //   );
  // }

  Map<String, dynamic> toMap() {
    return {
      'booking_timestamp': bookingTime,
      'date' : slotDate,
      'operator_uid': operatorUid,
      'remaining_slots': remainingSlots,
      'request_type': requestType,
      'slots_per_hour': slotsPerHour,
      'status' : status,
      'time_slot':timeSlot,
      'uid' : uid,
      'user_uid':userUid,
      'tracking':tracking
      // 'location': location.toMap(),
      // 'updateItems': updateItems.map((x) => x.toMap()).toList(),
    };
  }

  Booking.fromMap(QueryDocumentSnapshot<Map<String, dynamic>> map)
  : bookingTime= map['booking_timestamp'],
      slotDate= map['date'],
      operatorUid= map['operator_uid'],
      remainingSlots = map['remaining_slots'],
      requestType = map['request_type'],
      slotsPerHour= map['slots_per_hour'],
      status= map['status'],
      timeSlot = map['time_slot'],
      uid = map['uid'],
      userUid = map['user_uid'],
      tracking = map['tracking'];
  }

  // String toJson() => json.encode(toMap());

  // factory Booking.fromJson(String source) =>
  //     Booking.fromMap(json.decode(source));

  // @override
  // String toString() {
  //   return 'Booking(flag:$flag, slot:$slot, dateTime: $dateTime, userPhone: $userPhone, userName: $userName, address: $address, location: $location, updateItems: $updateItems, status:$status)';
  // }

//   @override
//   bool operator ==(Object other) {
//     if (identical(this, other)) return true;

//     return other is Booking &&
//         other.flag == flag &&
//         other.slot == slot &&
//         other.dateTime == dateTime &&
//         other.userPhone == userPhone &&
//         other.userName == userName &&
//         other.address == address &&
//         other.location == location &&
//         listEquals(other.updateItems, updateItems) &&
//         other.status == other.status;
//   }

//   @override
//   int get hashCode {
//     return flag.hashCode ^
//         slot.hashCode ^
//         dateTime.hashCode ^
//         userPhone.hashCode ^
//         userName.hashCode ^
//         address.hashCode ^
//         location.hashCode ^
//         updateItems.hashCode ^
//         status.hashCode ;
//   }
// }